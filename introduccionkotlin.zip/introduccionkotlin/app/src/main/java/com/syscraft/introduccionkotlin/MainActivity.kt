package com.syscraft.introduccionkotlin

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    companion object{
        const val moneda = "EUR"
    }
    var saldo: Float = 300.54f
    var sueldo: Float = 764.82f
    var entero: Int =62

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val fecha = "01/06/1990"
        //0123456789
        var nombre: String = "jota"
        var vip : Boolean = false
        var inicial: Char = 'J'

        var saludo = "Hola " + nombre

        if (vip == true) saludo += ", te queremos mucho"
        else saludo += ", quieres ser vip? paga la cuota"
        mostrar_saldo()

        var dia = fecha.subSequence(0, 2).toString().toInt()
        if (dia == 1) ingresar_sueldo()

        var mes = fecha.subSequence(3, 5).toString().toInt()

        when(mes){
            1 -> print("\n En Enero hay la super oferta del 7% de interés")
            2, 3 -> print("\n En invierno no hay ofertas de inversiones")
            4, 5, 6 -> print("\n En primavera hay ofertas de inversiones con el 1.5% de interés")
            7, 8, 9 -> print("\n En verano hay ofertas de inversiones con el 2.5% de interés")
            10, 11, 12 -> print("\n En otoño hay ofertas de inversiones con el 3.5% de interés")
            else -> print("\n La fecha es errónea")
        }

        println(saludo)

        var pin: Int = 1234
        var intentos: Int = 0
        var clave_ingresada: Int = 1230

        do {
            println("Ingrese el PIN: ")
            println("Clave ingresada: ${clave_ingresada++}")
            intentos++
        } while (intentos < 3 && clave_ingresada != pin)

        if (intentos == 3) println("Tarjeta Bloqueada")

        mostrar_saldo()
        ingresar_dinero(50.5f)
        retirar_dinero(40f)

        var a: Boolean = true
        var b: Boolean = true
        var c: Boolean = false
        var d: Boolean = false

        a && b       // && = AND        CONDICION  &&  CONDICION
        //                 A == 5     3 <= VALOR
        a || c       // || = OR         CONDICION  ||  CONDICION
        a && c
        c && c

        !d           // ! = NEGACION



        /*val a:Int = 5 + 5 // 10
        val b:Int = 10 - 5 // 5
        val c:Int = 3 * 4 // 12
        val d:Int = 10 / 3 // 3, no se puede dividir, se queda con el resto
        val e:Int = 10 % 3 // 1, división infinita, solo se mantiene la parte entera

        var aPreIncremento: Int = 5
        var bPreDecremento: Int = 5
        var cPostIncremento: Int = 5
        var dPostDecremento: Int = 5

        println(aPreIncremento)
        println(++aPreIncremento) // Incrementa primero, luego regresa. Salida: 6
        println(aPreIncremento)

        println(bPreDecremento)
        println(--bPreDecremento) // Primero decrementa, luego regresa. Salida: 4
        println(bPreDecremento)

        println(cPostIncremento)
        println(cPostIncremento++) // Primero regresa, luego incrementa. Salida: 5
        println(cPostIncremento)

        println(dPostDecremento)
        println(dPostDecremento--) // Primero regresa, luego decrementa. Salida: 5
        println(dPostDecremento)

        saldo += sueldo

        saldo++

        //operadores
        a==b
        a!=b
        a< b
        a > b
        a >= b
        a <= b*/


    }

    fun mostrar_saldo(){
        println("Tienes $saldo $moneda")
    }
    fun ingresar_sueldo(){
        saldo+=sueldo
        println("se ha ingresado tu sueldo de $sueldo $moneda")
        mostrar_saldo()
    }
    fun ingresar_dinero(cantidad: Float) {
        saldo += cantidad
        println("Se ha ingresado $sueldo $moneda")
        mostrar_saldo()
    }
    fun retirar_dinero(cantidad: Float) {
        if(verificarCantidad(cantidad)){
            saldo -= cantidad
            println("Se ha hecho una retirada de $sueldo $moneda")
            mostrar_saldo()
        }else println ("cantidad superior al saldo imposible hacer la operacion")
    }
    fun verificarCantidad(cantidad_a_retirar : Float) : Boolean{
        if(cantidad_a_retirar>saldo) return false
        else return true
    }

}